const menuItems = {
    "appetizers": [
        { name: "Salad", price: 5, image: "photos/salad.jpg" },
        { name: "Soup", price: 4, image: "photos/soup.jpg" },
        { name: "Garlic Bread", price: 3, image: "photos/garlic_bread.jpg" }
    ],
    "main-course": [
        { name: "Steak", price: 15, image: "photos/steak.jpg" },
        { name: "Pasta", price: 12, image: "photos/pasta.jpg" },
        { name: "Burger", price: 10, image: "photos/burger.jpg" }
    ],
    "dessert": [
        { name: "Cake", price: 6, image: "photos/cake.jpg" },
        { name: "Ice Cream", price: 4, image: "photos/ice_cream.jpg" },
        { name: "Fruit Salad", price: 5, image: "photos/fruit_salad.jpg" }
    ],
    "drinks": [
        { name: "Tea", price: 2, image: "photos/tea.jpg" },
        { name: "Juice", price: 3, image: "photos/juice.jpg" },
        { name: "Water", price: 1, image: "photos/water.jpg" }
    ]
};

function showSection() {
    const section = document.getElementById("menu").value;
    if (!section) return; // 🔧 Fix: don't run if nothing selected
    const menuItemsDiv = document.getElementById("menuItems");
    menuItemsDiv.innerHTML = "";
    menuItems[section].forEach(item => {
        const itemDiv = document.createElement("div");
        itemDiv.classList.add("menuItem");
        itemDiv.innerHTML = `
            <img src="${item.image}" alt="${item.name}">
            <span>${item.name}</span>
            <select onchange="addToCart(this.value, '${item.name}', ${item.price})">
                <option value="0">0</option>
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
            </select>
            <span>${item.price.toFixed(2)} SAR</span>
        `;
        menuItemsDiv.appendChild(itemDiv);
    });
}

function addToCart(quantity, itemName, price) {
    if (parseInt(quantity) === 0) return; // 🔧 Fix: don't add if quantity is 0
    let cart = JSON.parse(localStorage.getItem('cart')) || [];

    const existing = cart.find(i => i.name === itemName); // 🔧 Fix: update instead of duplicate
    if (existing) {
        existing.quantity = parseInt(quantity);
    } else {
        cart.push({ name: itemName, quantity: parseInt(quantity), price: price });
    }

    localStorage.setItem('cart', JSON.stringify(cart));
}