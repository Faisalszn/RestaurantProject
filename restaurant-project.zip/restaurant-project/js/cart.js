function printCart() {
    window.print(); 
localStorage.removeItem('cart');
}

const cartItems = JSON.parse(localStorage.getItem('cart')) || [];

const cartItemsBody = document.getElementById("cartItems");
let totalPrice = 0;
cartItems.forEach(item => {
    const row = document.createElement("tr");
    row.innerHTML = `
        <td>${item.name}</td>
        <td>${item.quantity}</td>
        <td>${(item.quantity * item.price).toFixed(2)} SAR</td>
    `;
    cartItemsBody.appendChild(row);
    totalPrice += item.quantity * item.price;
});

const totalDiv = document.getElementById("total");
totalDiv.textContent = `Total: ${totalPrice.toFixed(2)} SAR`;