<?php
include 'connect.php';

$id  = intval($_GET['id']);
$sql = "DELETE FROM menu_items WHERE id = $id";

if ($conn->query($sql) === TRUE) {
    header("Location: admin.php");
    exit();
} else {
    echo "Error deleting item: " . $conn->error;
}
?>